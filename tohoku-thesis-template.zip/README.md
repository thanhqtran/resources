# A Template for M.Sc./ Ph.D. Thesis at Tohoku University

## How to use:

Download the the .zip file here: [thesis-template.zip](https://github.com/thanhqtran/resources/blob/7433cced2d78a5051f7b42fe9bfdf182806b91c8/tohoku-thesis-template/tohoku-thesis-template.zip)

or from the release page.

Unzip, edit accordingly to your liking.

## Demo

The title page

![](https://i.imgur.com/KvsR450.jpg)